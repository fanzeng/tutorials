double mysqrt(double inputValue);
